# Poseidon2 ZK Full Project

This project implements the Poseidon2 hash function circuit using circom 2.1.6.

## Structure
- src/: Circuit source code
- scripts/: Compilation and proof scripts
- input.json: Sample input
- README.md: This document

## Usage
1. Compile circuit:
   ```bash
   bash scripts/compile.sh
   ```
2. Generate proof:
   ```bash
   bash scripts/generate_proof.sh
   ```

## Parameters
- n=256, t=3, d=5
- Uses Groth16 proving system


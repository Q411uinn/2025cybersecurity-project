#!/bin/bash
# 生成证明示例脚本
snarkjs groth16 prove build/poseidon2_final.zkey build/input.json build/proof.json build/public.json

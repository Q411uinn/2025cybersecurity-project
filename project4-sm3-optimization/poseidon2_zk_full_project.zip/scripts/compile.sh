#!/bin/bash
# 编译circom电路
circom src/poseidon2.circom --r1cs --wasm --sym -o build
